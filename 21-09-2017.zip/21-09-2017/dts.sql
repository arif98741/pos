-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2017 at 01:09 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dts`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE `tbl_brand` (
  `brandid` int(11) NOT NULL,
  `brandname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`brandid`, `brandname`, `address`) VALUES
(1, 'Akij Ceramics Ltd', 'Mohakhali DOHS'),
(2, 'PRAN RFL Group', 'Tongi, Gazipur'),
(3, 'Navana Group', 'Farmgate Branch'),
(4, 'Bosundara Cement Ltd', 'Basundara, Baridara DOHS');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_color`
--

CREATE TABLE `tbl_color` (
  `colorid` int(11) NOT NULL,
  `colorname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_color`
--

INSERT INTO `tbl_color` (`colorid`, `colorname`) VALUES
(1, 'blue'),
(2, 'lightblue'),
(3, 'green'),
(4, 'lightgreen'),
(5, 'brown'),
(6, 'black'),
(7, 'ash'),
(8, 'yellow'),
(9, 'pink');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_group`
--

CREATE TABLE `tbl_group` (
  `groupid` int(11) NOT NULL,
  `groupname` varchar(50) NOT NULL,
  `typeid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_group`
--

INSERT INTO `tbl_group` (`groupid`, `groupname`, `typeid`) VALUES
(1, 'Wall', 1),
(2, 'Varanda', 2),
(3, 'Room', 2),
(4, 'Floor', 3),
(5, 'Rooftop', 1),
(6, 'Layout', 1),
(7, 'Front', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `serial` int(11) NOT NULL,
  `product_id` varchar(8) NOT NULL,
  `product_type` int(11) NOT NULL,
  `product_group` int(11) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `product_brand` int(11) NOT NULL,
  `size_h` int(4) NOT NULL,
  `size_w` int(4) NOT NULL,
  `color` text NOT NULL,
  `price` float NOT NULL DEFAULT '0',
  `unit_price` float NOT NULL DEFAULT '0',
  `purchase_price` float NOT NULL DEFAULT '0',
  `piece_in_a_carton` int(11) DEFAULT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`serial`, `product_id`, `product_type`, `product_group`, `product_name`, `product_brand`, `size_h`, `size_w`, `color`, `price`, `unit_price`, `purchase_price`, `piece_in_a_carton`, `last_update`) VALUES
(62, '1201', 2, 2, 'Navana Chair', 1, 65, 67, 'Lightblue', 1201, 678, 453, 4343, '2017-09-20 22:09:53'),
(64, '1257', 2, 1, 'RFL Tul', 2, 34, 343, 'Magento', 1257, 3232, 3433, 343, '2017-09-20 22:09:46'),
(65, '455', 3, 3, 'Pran Hotpot', 4, 34, 454, 'White', 455, 454, 454, 56, '2017-09-20 22:09:45'),
(67, '1280', 6, 1, 'Something', 3, 34, 34, 'Green`', 1280, 546.45, 453.53, 34, '2017-09-20 22:09:53'),
(68, '1250', 5, 6, 'qfdgf', 2, 45, 67, 'Lightgray', 1250, 567, 545, 909, '2017-09-20 22:09:44'),
(70, '1214', 2, 2, 'Navana Chair', 1, 65, 67, 'Lightblue', 1214, 678, 453, 4343, '2017-09-20 22:09:54'),
(71, '4521', 3, 3, 'Pran Hotpot', 4, 34, 454, 'White', 455, 454, 454, 56, '2017-09-20 22:09:45'),
(72, '1260', 5, 6, 'qfdgf', 2, 45, 67, 'Lightgray', 1260, 567, 545, 909, '2017-09-20 22:09:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE `tbl_supplier` (
  `serial` int(11) NOT NULL,
  `supplier_id` varchar(10) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `opening_balance` float NOT NULL,
  `remark` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`serial`, `supplier_id`, `supplier_name`, `address`, `contact_no`, `email`, `contact_person`, `opening_balance`, `remark`) VALUES
(42, '2', 'Ariful Islam', 'Elenga,Tangail,Bangladesh', '01750-840217', 'arif98741@gmail.com', 'Arif', 12600, 'Not Bad'),
(43, '3', 'Shamim Al-Deen', 'Dhalapara, Ghatail, Tangail', '01738-298666', 'shamim@gmail.com', 'Shamim', 14500, 'Good'),
(45, '4', 'John Doe', 'New York City', '012-2142-2350', 'john@gmail.com', 'John', 12987, 'Fantastic'),
(46, '5', 'dsfdsf', 'dsfds', 'fdsfds', 'dsfdsfdsf', 'fds', 0, 'fdsfd'),
(47, '5', 'Sadiqur Rahman Rifat', 'Jamal Sadar, Jamalpur', '01866-XXXXXX', '5', 'Rifat', 3500, 'Outstanding');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_type`
--

CREATE TABLE `tbl_type` (
  `typeid` int(11) NOT NULL,
  `typename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_type`
--

INSERT INTO `tbl_type` (`typeid`, `typename`) VALUES
(1, 'SQFT'),
(2, 'DQPT'),
(3, 'PTPT'),
(4, 'SLDT'),
(5, 'RAPF'),
(6, 'BASF');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `accessibility` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`userid`, `username`, `password`, `name`, `email`, `accessibility`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Ariful Islam', 'admin@gmail.com', 'admin'),
(2, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'Shamim Al-Deen', 'user@gmail.com', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  ADD PRIMARY KEY (`brandid`);

--
-- Indexes for table `tbl_color`
--
ALTER TABLE `tbl_color`
  ADD PRIMARY KEY (`colorid`);

--
-- Indexes for table `tbl_group`
--
ALTER TABLE `tbl_group`
  ADD PRIMARY KEY (`groupid`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`serial`);

--
-- Indexes for table `tbl_supplier`
--
ALTER TABLE `tbl_supplier`
  ADD PRIMARY KEY (`serial`);

--
-- Indexes for table `tbl_type`
--
ALTER TABLE `tbl_type`
  ADD PRIMARY KEY (`typeid`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_brand`
--
ALTER TABLE `tbl_brand`
  MODIFY `brandid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_color`
--
ALTER TABLE `tbl_color`
  MODIFY `colorid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_group`
--
ALTER TABLE `tbl_group`
  MODIFY `groupid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;
--
-- AUTO_INCREMENT for table `tbl_supplier`
--
ALTER TABLE `tbl_supplier`
  MODIFY `serial` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `tbl_type`
--
ALTER TABLE `tbl_type`
  MODIFY `typeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
